# Simple Game Tutorial - HTML/Javascript
By: Omar Ozgur


This is the first project in my "Simple Game Tutorial" series, where I create the same simple game in various languages. 

Feel free to check out my code and use it anywhere you would like.

Check out the game at this link: https://dl.dropboxusercontent.com/u/17457307/SGT-Javascript/index.html
